plan.txt ------------------------
My initial plan on how I though the attack should proceed

walkthrough.txt ----------------------
Comments on the problems I faced and what I did to get around

dns/ ----------------------
Configuration files to setup dns

dhcp_server/ -------------------
Run a dhcp_server in c capable of offering one ip

dhcp_starvation/ ----------------------
Run dhcp starvation attack using Raw sockets and randomized macs

alpine.iso -------------------
The VM used to perform the attacks on
