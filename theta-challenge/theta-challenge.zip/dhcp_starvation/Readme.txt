dhcp.c------------
randomizes macs and sends multiple dhcp requests¸ accepting each offer it gets to get all the possible leases.
Could not get this to attack my router but it works for dhcp servers implemented with isc-dhcp
