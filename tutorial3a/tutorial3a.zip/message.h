#ifndef MESSAGE_H
#define MESSAGE_H

#define MAX_MSG_LEN 256

#endif // MESSAGE_H
